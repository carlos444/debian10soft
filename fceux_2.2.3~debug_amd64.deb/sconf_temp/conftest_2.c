

#include "zlib.h"

int
main() {
  inflate;
return 0;
}
